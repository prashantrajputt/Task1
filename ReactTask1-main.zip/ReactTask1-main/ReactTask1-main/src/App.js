import './App.css';
import {Box} from "./components/box";

function App() {
  return (
    <div>
      <Box heading="Responsive Paragraph Word Counter"/>
    </div>
  );
}

export default App;